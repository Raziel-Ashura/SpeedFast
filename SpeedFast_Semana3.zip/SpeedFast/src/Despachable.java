//Método Despachable solicitado.

public interface Despachable {
    void despachar();
}
