//Método Cancelable solicitado.

public interface Cancelable {
    void cancelar();
}