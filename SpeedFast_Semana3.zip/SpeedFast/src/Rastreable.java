//Método rastreable solicitado. Crea la lista también.

import java.util.List;

public interface Rastreable {
    void verHistorial();
}